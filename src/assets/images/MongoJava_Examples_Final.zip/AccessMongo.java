import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.*;

public class AccessMongo extends JFrame {

	JTextField input;
	JTextArea output;
	
	WindowListener exitListener = null;
	
	MongoDatabase sampleDB = null;
	MongoClient client = null;
	MongoCollection<Document> collection = null;
	MongoCursor<Document> cursor = null;
	
	//Constructor
	public AccessMongo() {
		
		setSize(600, 200);
		setLocation(400, 500);
		
		setTitle("Access MongoDB");
		
		
		Container cont = getContentPane();
		cont.setLayout(new BorderLayout());
		
		JButton search = new JButton("Search");
		JButton connect = new JButton("Connect");
		JButton clear = new JButton("Clear");
		
		input = new JTextField(20);
		output = new JTextArea(10, 30);
		
		JScrollPane scrollOutput = new JScrollPane(output);

		JPanel northPanel = new JPanel();
		northPanel.setLayout(new FlowLayout());
		northPanel.add(connect);
		northPanel.add(input);
		northPanel.add(search);
		northPanel.add(clear);
		
		cont.add(northPanel, BorderLayout.NORTH);
		cont.add(scrollOutput, BorderLayout.CENTER);
		
		connect.addActionListener(new ConnectMongo());
		clear.addActionListener(new ClearMongo());
		search.addActionListener(new GetMongo());

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		exitListener = new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				
				int confirm = JOptionPane.showOptionDialog(null, 
								"Are you sure that you want to close me :( ?", 
								"Exit Confirmation", 
								JOptionPane.YES_NO_OPTION, 
								JOptionPane.QUESTION_MESSAGE, 
								null, null, null);
				
				if(confirm == 0) {
					client.close();
					System.exit(0);
				}
			}
			
		};
		
		addWindowListener(exitListener);
		
		setVisible(true);
	}
	
	
	public static void main(String[] args) {
		
		AccessMongo obj = new AccessMongo();

	}
	
	
	class ConnectMongo implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			
			
			try {
				
				client = new MongoClient("localhost", 27017);
				
				MongoCursor<String> mc = client.listDatabaseNames().iterator();
				
				try {
					
					while(mc.hasNext()) {
						output.append(mc.next());
						output.append("\n");
					}
					
				} catch(MongoException e) {
					System.out.println(e.getMessage());
					System.out.println(e.toString());
					e.printStackTrace();
				} finally {
					mc.close();
				}
				
				sampleDB = client.getDatabase("SampleSocial");
				
				String dbName = sampleDB.getName();
				
				output.append("In Database: " + dbName + "\n");
				
				collection = sampleDB.getCollection("Tweets");
				
				output.append("Collection count: " + collection.count());
				
			} catch(Exception e) {
				System.out.println(e.getMessage());
				System.out.println(e.toString());
				e.printStackTrace();
				
				
				client.close();
			}
			
			
		}
		
		
		
	}// End class ConnectMongo
	
	class GetMongo implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			
			String inputText = input.getText();
			
			String regexPattern = "^" + inputText + ".*";
			
			int count = 0;
		
			cursor = collection.find(regex("text", regexPattern, "i")).iterator();
			
			try {
				while(cursor.hasNext()) {
					Document doc = cursor.next();
					
					output.append(doc.getString("text"));
					output.append("\n");
					output.append(doc.toJson());
					output.append("\n");
					
					count++;
				}
			} catch(MongoException ex) {
				System.out.println(ex.getMessage());
				System.out.println(ex.toString());
				ex.printStackTrace();
			} finally {
				cursor.close();
			}
			
			output.append("The count is " + count);
			
			
			
			
		}
		
	}
	
	
	class ClearMongo implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			output.setText("");
		}
		
	} // End class ClearMongo

}
