import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import static com.mongodb.client.model.Filters.*;

public class Regex {

    public static void main(String[] args) {

            MongoClient mongoClient = new MongoClient();
            MongoDatabase database = mongoClient.getDatabase("SampleSocial");
            MongoCollection collection = database.getCollection("Tweets");

            /*db.Tweets.find({ $and: [ {"text":  /\bDish\b/i}, { "text": {$not: /\bgood\b/i}
            }]}, { "text": 1, "_id": 0 } ).pretty()*/

            String fieldName = "text";
            String regex = "(\\bdish\\b)(?!.*?\\bgood\\b).*$";

            MongoCursor cursor = collection.find(regex(fieldName, regex, "i")).iterator();

            while (cursor.hasNext()) {
                Document doc = (Document)cursor.next();
                System.out.println(doc.get("text"));

            }

            mongoClient.close();

    }
}
