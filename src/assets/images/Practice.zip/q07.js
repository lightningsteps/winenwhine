//connect to mongo server
connection = new Mongo('localhost:27017');

//get the database
db = connection.getDB('SampleSocial');

//get the collection
collection = db.getCollection('Tweets');


cursor = collection.find({ LanguageCode: { $nin: [ "fr", "en", "es", "it", "vi", "ar", "in" ] }} );

while(cursor.hasNext()) {
    printjson(cursor.next());
}