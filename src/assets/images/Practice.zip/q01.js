//connect to mongo server
connection = new Mongo('localhost:27017');

//get the database
db = connection.getDB('SampleSocial');

//get the collection
collection = db.getCollection('Tweets');

result = collection.insert({ fromUser: "mxz4754", 
							 fromUserName: 'Marko Zelenkovic',
							 text: "This is a test!",
							 cnt: 0 });
print("");
print("Insert finished");
printjson(result);