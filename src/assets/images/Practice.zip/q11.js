conn = new Mongo('localhost:27017');
db = conn.getDB('SandyTweets');

cursor = db.Tweets.find(
	{

		loc : {
			$near: {
				$geometry: {
					type: "Point",
					coordinates: [-76.154480, 43.088947]
				},
				$maxDistance: 5000
			}
		}
	
	}, { _id: 0, id: 1, fromUserName: 1, loc: 1, text: 1 }
);

while (cursor.hasNext()) {
	printjson(cursor.next());
}