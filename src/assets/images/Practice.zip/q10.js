conn = new Mongo('localhost:27017');
db = conn.getDB('SandyTweets');
collection = db.getCollection('Tweets');

collection.createIndex({ loc: "2dsphere"});

docs = collection.getIndexes();
printjson(docs);