conn = new Mongo('localhost:27017');
db = conn.getDB('SandyTweets');

db.Tweets.find().snapshot().forEach(
    function(e) {

        if('latitude' in e && e.latitude !== "") {

            var ll = { longitude: e.longitude, latitude: e.latitude };
            var llArr = [];

            Object.keys(ll).forEach(function(key) {
                var value = ll[key];
                llArr.push(value);
            })

            var p = "Point";

             e.loc = {type: p, coordinates: llArr};
            //delete e.loc;

            // printjson(e);
            db.Tweets.save(e);

        }


    }
)