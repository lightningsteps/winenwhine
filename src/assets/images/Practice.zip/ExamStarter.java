import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.lang.reflect.Array;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
//Mongo Imports	
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.util.JSON;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
//import static com.mongodb.client.model.Projections.*;
import static com.mongodb.client.model.Filters.*;
import org.bson.Document;
import com.mongodb.MongoException;
//import com.mongodb.WriteConcern;
//import static com.mongodb.client.model.Sorts.ascending;
//import static com.mongodb.client.model.Sorts.descending;

//import org.bson.conversions.Bson;
//import com.mongodb.client.model.Filters;

//Log message control imports
import java.util.logging.Logger;
import java.util.logging.Level;

//Java imports

import java.util.Arrays;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;

public class ExamStarter extends JFrame {

	JTextField input;
	JTextArea output;
	
	MongoDatabase sampleDB = null;
   MongoClient client = null;
	MongoCollection<Document> collection = null;
	MongoCursor<Document> cursor = null;
   WindowListener exitListener = null;
	
	public ExamStarter() {
		setSize(600, 200);
		setLocation(400, 500);
		setTitle("Access MongoDB");
		
		Container cont = getContentPane();
		cont.setLayout(new BorderLayout() );
		
		JButton search = new JButton("Search");
		JButton connect = new JButton("Connect");
		JButton clear = new JButton("Clear");
		
		input = new JTextField(20);
		
		output = new JTextArea(10, 30);
		JScrollPane spOutput = new JScrollPane(output);
		
		JPanel northPanel = new JPanel();
		northPanel.setLayout(new FlowLayout());
		northPanel.add(connect);
		northPanel.add(input);
		northPanel.add(search);
		northPanel.add(clear);
		
		cont.add(northPanel, BorderLayout.NORTH);
				
		cont.add(spOutput, BorderLayout.CENTER);
		
		connect.addActionListener(new ConnectMongo());
		search.addActionListener(new GetMongo());
		clear.addActionListener(new ClearMongo());
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
      
      exitListener = new WindowAdapter() {

      @Override
      public void windowClosing(WindowEvent e) {
            int confirm = JOptionPane.showOptionDialog(
               null, "Are You Sure to Close Application?", 
               "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
               JOptionPane.QUESTION_MESSAGE, null, null, null);
            
            if (confirm == 0) {
               // Close the Mongo Client               
               System.exit(0);
            }
         }
      };
      
      addWindowListener(exitListener);



		setVisible(true);
		
	
	} //ExamStarter
	
	public static void main (String [] args) {
		
// The following statements are used to eliminate MongoDB Logging
//   information suche as INFO messages that the user should not see.
// It requires the import of Logger and Level classes.
      //Logger mongoLogger = Logger.getLogger( "org.mongodb.driver" );
      //mongoLogger.setLevel(Level.INFO); 
      
      
      ExamStarter runIt = new ExamStarter();
	
	}//main
	
	class ConnectMongo implements ActionListener {
		public void actionPerformed (ActionEvent event) {
		//Remember to connect to the MongoDB server, connect to the database and connect to the 
		//    desired collection
		
      // PUT CONNECTION CODE HERE
      
			try {
				client = new MongoClient("localhost", 27017);
			} catch(Exception e) {
				System.out.println(e.getMessage());
				System.out.println(e.toString());
				e.printStackTrace();

				client.close();
			}
      
		}//actionPerformed
	
	
	}//class ConnectMongo

	class GetMongo implements ActionListener {
		public void actionPerformed (ActionEvent event) {
// In this section you should retrieve the data from the collection
// and use a cursor to list the data in the output JTextArea
//   use the command  output.append(..... + "\n");
         
         // PUT YOUR QUERY CODE HERE
			/*String string = 
			{
			loc : {
					  $near: 
					  {
						$geometry: 
							{
							type: 'Point',
							coordinates: [-76.154480, 43.088947]
							},
						$maxDistance: 5000
					  }
				  }
			}
			*/
	         
			/*BasicDBObject query = 
					new BasicDBObject("loc", 
						new BasicDBObject("$near", 
						new BasicDBObject("$geometry", 
						new BasicDBObject("type", "Point"),
						new BasicDBObject("coordinates", [-76.154480, 43.088947])),
						new BasicDBObject("$maxDistance", 5000))
					);
			*/
			
			double[] array = new double[]{-76.154480, 43.088947};
			
			BasicDBObject query = 
					new BasicDBObject("loc", 
						new BasicDBObject("$near",
						new BasicDBObject("$geometry",
						new BasicDBObject("type", "Point").append("coordinates", array)).append("$maxDistance", 5000))
					);
			
			
			cursor = collection.find(query).iterator();
			
			try {
				while(cursor.hasNext()) {
					Document doc = cursor.next();
					
					output.append(doc.getString("text"));
					output.append("\n");
					output.append(doc.toJson());
					output.append("\n");
				}
			} catch(MongoException ex) {
				System.out.println(ex.getMessage());
				System.out.println(ex.toString());
				ex.printStackTrace();
			} finally {
				cursor.close();
			}
			

      	}//actionPerformed
         
	}//class GetMongo
	
	class ClearMongo implements ActionListener {
		public void actionPerformed (ActionEvent event) {
		//in this section open the connection. Should be able to see if it is not null
		// to see if ti is already open
			output.setText("");
		
		}//actionPerformed	
	
	}//class ClearMongo

} //class