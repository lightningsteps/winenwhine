//connect to mongo server
connection = new Mongo('localhost:27017');

//get the database
db = connection.getDB('SandyTweets');

//get the collection
collection = db.getCollection('Tweets');


cursor = collection.find( {$and: [ { LanguageCode: "un" }, { text: {$regex: ".*http.*"} } ]});

while(cursor.hasNext()) {
    printjson(cursor.next());
}